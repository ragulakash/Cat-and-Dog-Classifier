import React from 'react';
import { Cat, Dog, Sparkles } from 'lucide-react';

interface ClassificationResultProps {
  result: {
    prediction: 'cat' | 'dog';
    confidence: number;
  } | null;
  isClassifying: boolean;
}

export const ClassificationResult: React.FC<ClassificationResultProps> = ({
  result,
  isClassifying
}) => {
  if (isClassifying) {
    return (
      <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100">
        <div className="text-center space-y-4">
          <div className="relative">
            <div className="w-16 h-16 mx-auto bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center animate-pulse">
              <Sparkles className="w-8 h-8 text-white animate-spin" />
            </div>
            <div className="absolute inset-0 w-16 h-16 mx-auto bg-gradient-to-r from-blue-500 to-purple-600 rounded-full animate-ping opacity-20"></div>
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Analyzing Image...</h3>
            <p className="text-gray-600">Our AI is determining if this is a cat or dog</p>
          </div>
          <div className="flex justify-center space-x-1">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!result) return null;

  const { prediction, confidence } = result;
  const percentage = Math.round(confidence * 100);
  const isHighConfidence = confidence > 0.8;

  return (
    <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100 transform animate-fadeIn">
      <div className="text-center space-y-6">
        <div className="relative">
          <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center ${
            prediction === 'cat' 
              ? 'bg-gradient-to-r from-orange-400 to-pink-500' 
              : 'bg-gradient-to-r from-blue-400 to-indigo-500'
          }`}>
            {prediction === 'cat' ? (
              <Cat className="w-10 h-10 text-white" />
            ) : (
              <Dog className="w-10 h-10 text-white" />
            )}
          </div>
          {isHighConfidence && (
            <div className="absolute -top-2 -right-2">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            </div>
          )}
        </div>

        <div>
          <h3 className="text-3xl font-bold text-gray-800 mb-2 capitalize">
            It's a {prediction}!
          </h3>
          <p className="text-gray-600">
            {isHighConfidence 
              ? "I'm very confident about this prediction" 
              : "This is my best guess based on the image"
            }
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between items-center text-sm font-medium text-gray-700">
            <span>Confidence Level</span>
            <span>{percentage}%</span>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-1000 ease-out ${
                prediction === 'cat'
                  ? 'bg-gradient-to-r from-orange-400 to-pink-500'
                  : 'bg-gradient-to-r from-blue-400 to-indigo-500'
              }`}
              style={{ width: `${percentage}%` }}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className={`p-3 rounded-xl border-2 transition-all duration-300 ${
              prediction === 'cat' 
                ? 'border-orange-300 bg-orange-50' 
                : 'border-gray-200 bg-gray-50'
            }`}>
              <div className="flex items-center space-x-2">
                <Cat className={`w-5 h-5 ${prediction === 'cat' ? 'text-orange-600' : 'text-gray-400'}`} />
                <span className={`font-medium ${prediction === 'cat' ? 'text-orange-800' : 'text-gray-500'}`}>
                  Cat
                </span>
              </div>
              <div className="text-sm mt-1 font-semibold">
                {prediction === 'cat' ? `${percentage}%` : `${100 - percentage}%`}
              </div>
            </div>
            
            <div className={`p-3 rounded-xl border-2 transition-all duration-300 ${
              prediction === 'dog' 
                ? 'border-blue-300 bg-blue-50' 
                : 'border-gray-200 bg-gray-50'
            }`}>
              <div className="flex items-center space-x-2">
                <Dog className={`w-5 h-5 ${prediction === 'dog' ? 'text-blue-600' : 'text-gray-400'}`} />
                <span className={`font-medium ${prediction === 'dog' ? 'text-blue-800' : 'text-gray-500'}`}>
                  Dog
                </span>
              </div>
              <div className="text-sm mt-1 font-semibold">
                {prediction === 'dog' ? `${percentage}%` : `${100 - percentage}%`}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};