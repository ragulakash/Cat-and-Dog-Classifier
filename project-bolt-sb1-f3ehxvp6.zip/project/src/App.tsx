import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageUpload } from './components/ImageUpload';
import { ClassificationResult } from './components/ClassificationResult';
import { classifyImage } from './utils/classifier';
import { RotateCcw } from 'lucide-react';

interface ClassificationResult {
  prediction: 'cat' | 'dog';
  confidence: number;
}

function App() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isClassifying, setIsClassifying] = useState(false);
  const [result, setResult] = useState<ClassificationResult | null>(null);

  const handleImageSelect = useCallback(async (file: File) => {
    const imageUrl = URL.createObjectURL(file);
    setSelectedImage(imageUrl);
    setResult(null);
    setIsClassifying(true);

    try {
      const classification = await classifyImage(file);
      setResult(classification);
    } catch (error) {
      console.error('Classification failed:', error);
    } finally {
      setIsClassifying(false);
    }
  }, []);

  const handleClearImage = useCallback(() => {
    if (selectedImage) {
      URL.revokeObjectURL(selectedImage);
    }
    setSelectedImage(null);
    setResult(null);
    setIsClassifying(false);
  }, [selectedImage]);

  const handleTryAnother = useCallback(() => {
    handleClearImage();
  }, [handleClearImage]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-pink-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 max-w-4xl">
        <Header />
        
        <div className="space-y-8">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border border-white/20">
            <ImageUpload
              onImageSelect={handleImageSelect}
              selectedImage={selectedImage}
              onClearImage={handleClearImage}
              isClassifying={isClassifying}
            />
          </div>

          {(isClassifying || result) && (
            <div className="space-y-6">
              <ClassificationResult
                result={result}
                isClassifying={isClassifying}
              />
              
              {result && !isClassifying && (
                <div className="text-center">
                  <button
                    onClick={handleTryAnother}
                    className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
                  >
                    <RotateCcw className="w-5 h-5" />
                    <span>Try Another Image</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        <footer className="mt-16 text-center text-gray-500 text-sm">
          <p>
            Powered by AI • Built with React & TypeScript • 
            <span className="text-blue-600 font-medium"> Privacy-focused</span>
          </p>
        </footer>
      </div>
    </div>
  );
}

export default App;